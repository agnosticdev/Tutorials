//: Playground - noun: a place where people can play

// -------- Creating a Dictionary --------

// Create a new (key: string, value: string) dictionary and add three values using the subscript syntax
var stringDictionary: Dictionary = [String: String]()
stringDictionary["swift"] = "Swift is a great language"
stringDictionary["python"] = "Python is a great tool"
stringDictionary["cpp"] = "C++ is the best language"
print(stringDictionary["python"] ?? "No subscript found: 🙁")


// Create a new (key: integer, value: string) dictionary literal
var integerDictionaryLiteral: Dictionary = [
    45: "Swift Article",
    56: "Python Article",
    71: "C++ Article"
]
print(integerDictionaryLiteral[71] ?? "No subscript found: 🙁")


// Create a new unique dictionary out of an array of tuples containing duplicate keys
// https://developer.apple.com/documentation/swift/dictionary/2892961-init?changes=latest_minor
// Xcode 9 / Swift 4
let dupKeys = [("one", 1), ("one", 2), ("two", 2), ("three", 3), ("four", 4), ("five", 5)]
let nonDupDict = Dictionary(dupKeys, uniquingKeysWith: { (first, _) in first })
print(nonDupDict)

// Create a new dictionary by mapping an array of keys and values
// https://developer.apple.com/documentation/swift/dictionary/2894798-init?changes=latest_minor
// Xcode 9 / Swift 4
let evenKeys = ["two", "four", "six", "eight", "ten"]
var sequence = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
sequence = sequence.filter { $0 % 2 == 0 }
let evenDict = Dictionary(uniqueKeysWithValues: zip(evenKeys, sequence))
print(evenDict)



// -------- Modifying a Dictionary --------

// Updating a value in a dictionary using the subscript
integerDictionaryLiteral[56] = "Python 3.6 Article"
print(integerDictionaryLiteral[56] ?? "No subscript found: 🙁")

// Updating a value in a dictionary using updateValue(_:forKey:)
// https://developer.apple.com/documentation/swift/dictionary/1539001-updatevalue
// This method of updating a dictionary will add a value to a dictionary if one does not exist
if let updatedValue = integerDictionaryLiteral.updateValue("Python 3.7 is not out yet", forKey: 56) {
    print(updatedValue)  // Python 3.6 Article
    print(integerDictionaryLiteral[56] ?? "No subscript found: 🙁") // Python 3.7 is not out yet
}

// Removing a value in a dictionary using removeValue(forKey:)
// https://developer.apple.com/documentation/swift/dictionary/1641348-removevalue
// This method of updating a dictionary will remove a value in a dictionary if one exists
if let removedPythonValue = stringDictionary.removeValue(forKey: "python") {
    print(removedPythonValue) // Python is a great tool
    print(stringDictionary["python"] ?? "No subscript found: 🙁") // No subscript found: 🙁
}

// Merging the existing dictionary with a sequence of tuples to emulate a dictionary
// Xcode 9 / Swift 4
// https://developer.apple.com/documentation/swift/dictionary/2892855-merge?changes=latest_minor
var existing = ["one": 2, "two": 2, "three": 6]
let newData = [("one", 3), ("two", 1), ("three", 3), ("four", 4), ("five", 5)]
existing.merge(newData) { (current, _) in current }
print(existing) // ["three": 6, "four": 4, "five": 5, "one": 2, "two": 2]



// -------- Dictionary Grouping --------

let people = ["Matt", "Rich", "Mary", "Mike", "Karin", "Phil", "Edward", "Ken"]

// Group people into arrays with the first letter of their name as the key
// https://developer.apple.com/documentation/swift/dictionary/2893436-init
// Xcode 9 / Swift 4 (Proposal 165)
let groupedNameDictionary = Dictionary(grouping: people, by: { $0.characters.first! })
print(groupedNameDictionary)

// Group the people array into arrays with similar length and the integer length as the key for the dictionary
// https://github.com/apple/swift-evolution/blob/master/proposals/0165-dict.md#2-key-based-subscript-with-default-value
// Xcode 9 / Swift 4 (Proposal 165)
let groupedLengthDictionary = Dictionary(grouping: people) { $0.utf16.count }
print(groupedLengthDictionary)

